var inClassRoom = 'student'

if (inClassRoom === 'student'){
        console.log("student in a class")
}else if(inClassRoom === 'teacher'){
    console.log('teacher in a Class')
}else{
    console.log('no one in the class')
}