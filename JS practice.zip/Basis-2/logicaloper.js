var bharath = false
var sumanth = true
var arun = false
var murli = false

if ( bharath && sumanth && arun){
    console.log("going to out of town")
    console.log('weekend party')
}else if(arun || murli){
    console.log('going to movie')
}else if((sumanth && arun )|| bharath){
    console.log('going out for dinner')
}else{
    console.log('go to Hostel and have a good sleep')
}