// let laptops = 'carry'

// if (true){
//     var desktops = 'non-carry'
//     const laptops = 'weight less'
//     console.log(laptops)
//     console.log(desktops)
// }
// console.log(desktops)
// console.log(laptops)

var king = 'Bharath'

if(true){
    let king = 'Bob'
    if(true){
        let king = 'Marley'
        console.log(king)
    }
    console.log(king)
}
if (true){
    console.log(king)
}