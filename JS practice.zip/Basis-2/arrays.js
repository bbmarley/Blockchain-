// const superHeros = ['Spider Man', 'Hulk', 'Iron man' , 'SuperMan']

// console.log(superHeros)
// console.log(superHeros[3])
// console.log(superHeros[superHeros.length-3])
// console.log(`the powerful superHero is ${superHeros[superHeros.length-3]}`)

const series = ['one','two','three','four','five','six']

series[2] = 'bharath'
console.log(series);

//start
//shift is for to remove the first element in the array  

series.shift()
console.log(series);

// unshift is add the element in the array in first position
series.unshift('Marley')
console.log(series);

//end
// pop is for to delete the last element in the array
series.pop()
console.log(series)
//push is for to add the element in the last in a array 
series.push('bob','ram')
console.log(series)

//middle
// splice is for to add element in any position and delete elements in a array
series.splice(6,0,'ziggy')
console.log(series);
console.log(series.length)
var count = 0
while (count < series.length){
// for ( i=0 ; i<=series.length-1 ; i++ ){
//     // console.log((i+1)+' : ' +series[i])
//     return series[i]

// }
console.log(series[count])
count++;
}
// console.log('------------'+series[count])
