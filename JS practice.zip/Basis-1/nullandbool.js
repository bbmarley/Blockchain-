let temp = 0
// when we give temp = 0 it is undefined

console.log(temp)

let actualValue = 8

// we can any symbol like <,>,==,<=,>=,==!
console.log(actualValue ==! 8)