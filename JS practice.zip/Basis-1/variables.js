let firstName = 'Bharath'
let lastName = 'Marley'
let fullName = firstName + ' ' + lastName
let salary = 900
let bonus = 100
let totalSalary = salary + bonus
console.log(fullName)
console.log(totalSalary)