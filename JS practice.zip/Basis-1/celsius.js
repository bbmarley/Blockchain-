let tempInFahrenheit = 80

let celsius = (tempInFahrenheit - 32) * 5/9

console.log(celsius)