// let class1 = function(cMarks,tMarks){
//     let tM = (cMarks/tMarks)*100
//     if (tM >= 90){
//         console.log(`your current marks - ${cMarks} and your total marks - ${tMarks} and your Grade is A`)
//     }else if(tM >= 80 ){
//         console.log(`your current marks - ${cMarks} and your total marks - ${tMarks} and your Grade is B`)
//     }else if(tM >= 70 ){
//         console.log(`your current marks - ${cMarks} and your total marks - ${tMarks} and your Grade is C`)
//     }else if(tM >= 60 ){
//         console.log(`your current marks - ${cMarks} and your total marks - ${tMarks} and your Grade is D`)
//     }else if(tM >= 50 ){
//         console.log(`your current marks - ${cMarks} and your total marks - ${tMarks} and your Grade is E`)
//     }else{
//         console.log('your Grade is Fail')
//     }
//     return `your Percentage is ${tM}`
// }
// console.log(class1(69,70))


let Grade = function(cMarks,tMarks){
    // const tMarks = 120
    let percentage = (cMarks/tMarks)*100
    let yourGrade = ''

    if (percentage >= 90){
        yourGrade = 'A'
    }else if (percentage >= 80){
        yourGrade = 'B'
    }else if (percentage >= 70){
        yourGrade = 'C'
    }else if (percentage >= 60){
        yourGrade = 'D'
    }else if (percentage >= 50){
        yourGrade = 'E'
    }else {
        yourGrade = 'Fail'
    }
    return `Your Grade is ${yourGrade} and percentage is ${percentage}`     
}
let result = Grade(111,120)
console.log(result)