const list = []

list.unshift('day3')
list.unshift('day2')
list.unshift('day1')
list[0] = 'do workout for 1 hour'
list[1] = 'do workout at Evening'
list[2] = 'do your best'
list[3] = 'rest for entire day'
// console.log(list)
// list.forEach(function(lis,i){
//     console.log(`Workout process day ${i+1} - ${lis}` )
// })

for(i=0;i<list.length;i++){
    console.log(`Workout process day ${i+1} - ${list[i]}` )
}