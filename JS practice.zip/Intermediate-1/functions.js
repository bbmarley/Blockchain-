let welcome = function (name){
    console.log(`Hey ${name}`)
    console.log(`Greetings from Marley estates to ${name}`)
}

// welcome('Bharath')

let fullName = function (firstName,lastName){
    console.log(`Hey ${firstName} ${lastName} `)
    console.log(`welcome to my Grand Hotel ${firstName} ${lastName}`)
    // console.log(firstName,lastName)
}
// fullName('Bharath', 'Marley')

let cal = function(num1, num2){
    let add = num1 + num2
    let sub = num1 - num2
    let mul = num1 * num2
    let div = num1 / num2
    let mod = num1 % num2

    return ('addition = '+ add +" , Subtraction = "+ sub +" , Multiplication = "+ mul +" , Division = "+ div+" , percentage = "+ mod)
}
// console.log(cal(19,13))

let course = function( name = 'Unname', id = 'invalid'){
    return 'Hey '+ name + ' and your vaild id is '+ id
}

console.log(course('bharath',007))
console.log(course('Marley',110))