let week = ['sun','mon','tue','wed','thu','fri','sat']

//forloop

console.log('Regular order : ')
for(let index = 0; index < week.length ; index++){

    console.log(week[index])
}
// console.log(week[index])
console.log('Reverse order : ')
for (let index = week.length - 1; index >= 0; index--){

    console.log(week[index])
}