// let randomNum1 = 22
// let randomNum2 = 7

// result = 22/7

// console.log(Math.floor(result))
// console.log(Math.ceil(result))
// console.log(result.toFixed(4))

let uone = 6
let lone = 1
let RandomNumber = Math.floor(Math.random() * (uone - lone + 1) + lone)
console.log(RandomNumber)