let myCourse = {
    courseName: 'JavaScript',
    price: '799',
    author: 'Bharath Marley',
    description:'Used in Web pages, JavaScript is a client-side programming language. This means JavaScript scripts are read, interpreted and executed in the client, which is your Web browser. By comparison, server-side programming languages run on a remote computer, such as a server hosting a website.'

}
console.log(`Hey here is the new course is "${myCourse.courseName}" by "${myCourse.author}" at a price of "${myCourse.price}" and it has a description of "${myCourse.description}"`)