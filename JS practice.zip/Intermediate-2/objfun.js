let todo = {
    day: 'monday',
    meetings: 0,
    meetingsDone: 0,

    addMeeting: function(meet){
        this.meetings = this.meetings + meet
    
    },
    meetdone: function(meet){
            this.meetingsDone = this.meetingsDone + meet
            // this.meetings = this.meetings + meet

    },
    reset: function(){
        this.meetings = 0
        this.meetingsDone = 0

    },
    summary: function(i){
            // this.day[j] = todo.day[j]
            return i
    },
}
todo.addMeeting(5)
todo.meetdone(8)
todo.reset()
console.log(todo.summary(todo))