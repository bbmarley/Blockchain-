let userName = 'bharath123'
let password = 'bharath123'

let usercheck = function (user){
    if((user.includes(123)) && (user.length > 6)){
        return 'Successfully userName was created'
    }
        return 'Include your username with 123'
}

let passcheck = function(pass){
    if((pass.includes(123)) && (pass.length > 6)){
        return 'Successfully password was created'
    }
        return 'Include your password with 123'
}

console.log(usercheck(userName))
console.log(passcheck(password))
