var Web3 = require('web3')
var web3 = new Web3('http://localhost:8545');
console.log(web3)